<?php

interface WPML_ACF_Convertable {
	public function convert( WPML_ACF_Field $acf_field );
}
