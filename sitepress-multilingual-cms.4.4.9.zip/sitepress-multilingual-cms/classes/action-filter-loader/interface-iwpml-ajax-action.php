<?php
/**
 * @author OnTheGo Systems
 */
interface IWPML_AJAX_Action extends IWPML_Action {
}
